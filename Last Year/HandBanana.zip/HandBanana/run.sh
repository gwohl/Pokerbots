#!/bin/sh
python HandBanana.py $1
